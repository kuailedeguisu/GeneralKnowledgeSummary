You do not need to include Grid.cpp in your project.
