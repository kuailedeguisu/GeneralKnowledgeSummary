#include "Grid.h"

#include <iostream>
using namespace std;

int main()
{
	Grid<int> myGrid;
	Grid<int, 10> anotherGrid;
	Grid<int, 10, 10> aThirdGrid;

	return 0;
}
