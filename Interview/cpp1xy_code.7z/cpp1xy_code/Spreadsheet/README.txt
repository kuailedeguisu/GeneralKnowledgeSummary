Include SpreadsheetCell.cpp, SpreadsheetTest.cpp, and one of Spreadsheet.cpp
or SpreadsheetNoCopyFrom.cpp.
