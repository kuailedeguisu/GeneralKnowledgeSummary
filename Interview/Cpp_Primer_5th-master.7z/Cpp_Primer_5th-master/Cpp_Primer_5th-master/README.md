## 书籍请移步网盘

* [C++  Primer中文版（第五版）](https://pan.baidu.com/s/1i48my3b)

* [C++primer第五版（英文版）](https://pan.baidu.com/s/1nvuhuit)

* [C++ Primer习题集 第5版](https://pan.baidu.com/s/1eSqrQlO)
