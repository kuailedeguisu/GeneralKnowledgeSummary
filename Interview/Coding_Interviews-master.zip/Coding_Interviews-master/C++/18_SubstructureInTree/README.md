# 面试题18：树的子结构

> 题目：输入两棵二叉树A和B，判断B是不是A的子结构。二叉树结点的定义如下：

```c++
struct BinaryTreeNode
{
    int                    m_nValue;
    BinaryTreeNode*        m_pLeft;
    BinaryTreeNode*        m_pRight;
};
```
