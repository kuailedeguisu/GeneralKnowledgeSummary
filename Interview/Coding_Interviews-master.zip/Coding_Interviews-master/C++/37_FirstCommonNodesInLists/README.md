# 面试题37：两个链表的第一个公共结点

> 题目：输入两个链表，找出它们的第一个公共结点。链表结点定义如下：

```c++
struct ListNode
{
    int       m_nValue;
    ListNode* m_pNext;
};
```
