# 面试题11：数值的整数次方

> 题目：实现函数 `double Power(double base, int exponent)`，求base的exponent次方。不得使用库函数，同时不需要考虑大数问题。
