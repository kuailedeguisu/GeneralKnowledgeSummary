# 面试题5：从尾到头打印链表

> 题目：输入一个链表的头结点，从尾到头反过来打印出每个结点的值。链表结点定义如下：

```c++
struct ListNode
{
    int       m_nValue;
    ListNode* m_pNext;
};
```


