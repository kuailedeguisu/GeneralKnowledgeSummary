# 面试题9：斐波拉契数列

> 题目：写一个函数，输入n，求斐波拉契（Fibonacci）数列的第n项。斐波拉契数列的定义如下：

![fib1](https://wikimedia.org/api/rest_v1/media/math/render/svg/f00c4321176b6522fe148a11a80a8e5fca9e88da)，初始值：![fib1](https://wikimedia.org/api/rest_v1/media/math/render/svg/6890c552b2226e339520693a236386ed2346a63a)
