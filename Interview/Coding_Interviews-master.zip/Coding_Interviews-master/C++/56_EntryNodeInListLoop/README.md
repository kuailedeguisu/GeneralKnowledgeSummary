# 面试题56：链表中环的入口结点

> 题目：一个链表中包含环，如何找出环的入口结点？例如，在图8.3的链表中，环的入口结点是结点3。

![ring](https://github.com/familyld/Coding_Interviews/blob/master/graph/56_EntryNodeInListLoop.jpg?raw=true)
